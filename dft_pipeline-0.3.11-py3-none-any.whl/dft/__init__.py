"""DFT - Data Flow Tools

Flexible ETL pipeline framework for data analysts and engineers.
"""

__version__ = "0.1.8"
__title__ = "dft"
__author__ = "DFT Team"
__email__ = "team@dft.com"